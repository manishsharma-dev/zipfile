import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { FormArray, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HierarchyService } from '../../hierarchy-management/hierarchy.service';

import moment from 'moment';
import { UserManagementService } from '../../user-management/user-management.service';
import { ConfirmationDialogComponent } from 'src/app/shared/confirmation-dialog/confirmation-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { MisReportAccess } from '../models/mis-report-access.model';
import { MisReportServiceService } from '../mis-report-service.service';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
  selector: 'app-mis-access-report',
  templateUrl: './mis-access-report.component.html',
  styleUrls: ['./mis-access-report.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [TranslatePipe],
})
export class MisAccessReportComponent implements OnInit {
  public isLoadingSpinner = false;
  public misReportForm: FormGroup;
  public roleNameLists: any[] = [];
  public getFeatureLists: MisReportAccess[] = [];
  public userDetails: any;
  public step = 0;
  public setRoleCode: string | number;
  public todayDate: any = sessionStorage.getItem('serverCurrentDateTime');

  @ViewChild('errorElement') errorElement: ElementRef;

  constructor(
    public HierarchySrv: HierarchyService,
    private misReportSrv: MisReportServiceService,
    private fb: FormBuilder,
    public userService: UserManagementService,
    private dialog: MatDialog,
    private router: Router,
    private translatePipe: TranslatePipe
  ) {}

  ngOnInit(): void {
    this.misReportForm = this.fb.group({
      roleCd: [null, [Validators.required]],
      accessList: this.fb.array([]),
    });
    this.getUserDetail();
    this.getRoleNameList();
  }
  getUserDetail() {
    let data = JSON.parse(sessionStorage.getItem('user')).userId;
    this.isLoadingSpinner = true;
    this.userService.getDetailsByUserID(data).subscribe((response) => {
      this.userDetails = response;
    });
  }
  onGetFeatureMaster() {
    console.log(this.misReportForm.value.accessList);
    this.getFeatureLists = [];
    this.resetRow();
    if (this.misReportForm.invalid) {
      this.misReportForm.markAllAsTouched();
      //this.scrollToError();
      return;
    }

    this.isLoadingSpinner = true;
    if (!this.setRoleCode) {
      return;
    }
    this.misReportSrv.getFeatureMasterList(this.setRoleCode).subscribe(
      (data) => {
        this.getFeatureLists = data;
        this.getFeatureLists.forEach((itemlist, index) => {
          this.setMisReportForm(itemlist);
          this.patchRoleUsersForm(itemlist);
        });

        this.isLoadingSpinner = false;
      },
      (error) => {
        this.isLoadingSpinner = false;
      }
    );
  }
  get row() {
    return this.misReportForm.get('accessList') as FormArray;
  }

  private setMisReportForm(item: MisReportAccess) {
    item['features'].forEach((data: MisReportAccess) => {
      this.row.push(this.setMisReportFormArray(data, item));
    });
  }

  resetRow() {
    while (this.row.length > 0) {
      this.row.removeAt(0);
    }
  }

  getRoleNameList() {
    this.isLoadingSpinner = true;
    this.HierarchySrv.getRoleLists().subscribe(
      (response) => {
        this.roleNameLists = response.filter((ele) => {
          return ele.isActive == 'Y';
        });
        this.isLoadingSpinner = false;
      },
      (error) => {
        this.isLoadingSpinner = false;
      }
    );
  }

  setMisReportFormArray(user, item) {
    return this.fb.group({
      subModuleCd: [user.subModuleCd],
      featureCd: [user.featureCd],
      featureName: [user.featureName],
      allocationStartDate: [this.todayDate],
      allocationEndDate: [this.todayDate],
      effectiveFromDate: [user.effectiveFromDate],
      effectiveToDate: [user.effectiveToDate],
      isActive: [false],
      downloadFlag: [false],
    });
  }
  private patchRoleUsersForm(item: MisReportAccess) {
    this.isLoadingSpinner = true;
    this.row.value.forEach((row: MisReportAccess, index: number) => {
      let tempFilter = item['features'].find(
        (val) =>
          val.subModuleCd == row.subModuleCd && val.featureCd == row.featureCd
      );
      if (tempFilter) {
        this.row.at(index).patchValue({
          subModuleCd: tempFilter.subModuleCd,
          allocationStartDate: tempFilter.allocationStartDate,
          allocationEndDate: tempFilter.allocationEndDate,
          isActive: tempFilter.isActive == 'Y' ? true : false,
          downloadFlag: tempFilter.downloadFlag == 'Y' ? true : false,
          // isSubModule: (tempFilter.isView || tempFilter.isModify || tempFilter.isDelete || tempFilter.isView),
        });
      }
      //this.row.at(index).get('accessStartDate').disable();
    });
    this.isLoadingSpinner = false;
  }

  getRole(event: Event) {
    this.setRoleCode = event['roleCd'];
  }

  scrollToError() {
    if (this.errorElement && this.errorElement.nativeElement) {
      this.errorElement.nativeElement.scrollIntoView({ behavior: 'smooth' });
    }
  }

  onMisReportSubmit() {
    var acessAccessList = [];
    for (let subModule of this.misReportForm.getRawValue()['accessList']) {
      if (subModule) {
        subModule['allocationStartDate'] = moment(
          subModule.allocationStartDate
        ).format('YYYY-MM-DD');
        subModule['allocationEndDate'] = moment(
          subModule.allocationEndDate
        ).format('YYYY-MM-DD');
        acessAccessList.push(subModule);
      }
    }
    let misReportForm = {
      roleCd: this.misReportForm.get('roleCd').value,
      accessList: acessAccessList,
    };

    this.misReportSrv.OnFeatureMaster(misReportForm).subscribe(
      (response) => {
        if (response) {
          this.dialog
            .open(ConfirmationDialogComponent, {
              data: {
                title: this.translatePipe.transform('common.info_label'),
                message: `${response['message']}`,
                icon: 'assets/images/info.svg',
                primaryBtnText:
                  this.translatePipe.transform('common.ok_string'),
              },
              panelClass: 'common-info-dialog',
            })
            .afterClosed()
            .subscribe((result) => {
              if (result) {
                this.router.navigate(['/dashboard']);
              }
            });
          this.isLoadingSpinner = false;
        }
      },
      (error) => {
        this.isLoadingSpinner = false;
      }
    );
    // console.log(misReportForm);
  }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() {
    this.step--;
  }
}
