import { NgModule } from '@angular/core';
import { MisAccessReportComponent } from './list/mis-access-report.component';
import { RouterModule, Routes } from '@angular/router';

//child routing of component

const routes: Routes = [
  {
    path: 'list',
    component: MisAccessReportComponent,
  }

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MisAccessReportRoutingModule { }
