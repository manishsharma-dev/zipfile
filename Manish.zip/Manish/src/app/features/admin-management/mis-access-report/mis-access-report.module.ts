import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MisAccessReportComponent } from './list/mis-access-report.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { MisAccessReportRoutingModule } from './mis-access-report-routing.module';



@NgModule({
  declarations: [MisAccessReportComponent],
  imports: [
    CommonModule,
    MisAccessReportRoutingModule,
    SharedModule
  ]
})
export class MisAccessReportModule { }
