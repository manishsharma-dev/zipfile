import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
import { MisReportAccess } from './models/mis-report-access.model';

@Injectable({
  providedIn: 'root',
})
export class MisReportServiceService {
  public Url = environment.apiURL;
  constructor(private http: HttpClient) {}

  getFeatureMasterList(setRoleCode): Observable<MisReportAccess[]> {
    const payload = {
      roleCd: setRoleCode,
    };
    return this.http.post<MisReportAccess[]>(
      `${this.Url}commonutility/getFeatureMaster`,
      payload
    );
  }

  OnFeatureMaster(data: any): Observable<MisReportAccess[]> {
    return this.http.post<MisReportAccess[]>(
      `${this.Url}commonutility/createOrUpdateMISRoleAccess`,
      data
    );
  }
}
