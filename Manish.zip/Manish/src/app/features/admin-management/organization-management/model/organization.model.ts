export interface Organization {
  id: number;
  name: string;
  type: number;
  state: number;
  district: number;
  status: number;
}
