import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-organization-management',
  templateUrl: './organization-management.component.html',
  styleUrls: ['./organization-management.component.css']
})
export class OrganizationManagementComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
