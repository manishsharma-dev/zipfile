export interface Common {
    key: string,
    cd: number,
    value: string
  }