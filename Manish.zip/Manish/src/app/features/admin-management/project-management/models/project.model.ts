export interface Project {
  projectId: number;
  projectName: string;
  parentOrgName: string;
  userAllocation: string;
  startDate: string;
  endDate: string;
  status: string
}