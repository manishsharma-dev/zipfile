export interface ProjectUserAllocDelloc {
  userId: number;
  projectId: number;
  userName: string;
  userType: string;
  role: string;
  baseLocation: string
  projectStartDate: string;
  projectEndDate: string;
  state: string,
  organization: string
  type: string
  searchValue: string
  districts: [],
  roleCds: [],

}