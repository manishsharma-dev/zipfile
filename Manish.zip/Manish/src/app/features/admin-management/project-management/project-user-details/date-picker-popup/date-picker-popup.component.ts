import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-date-picker-popup',
  templateUrl: './date-picker-popup.component.html',
  styleUrls: ['./date-picker-popup.component.css']
})
export class DatePickerPopupComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
