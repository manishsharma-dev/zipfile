import {
  Component,
  ElementRef,
  Inject,
  OnInit,
  ViewChild,
  ViewEncapsulation,
} from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import {
  MAT_DIALOG_DATA,
  MatDialog,
  MatDialogRef,
} from '@angular/material/dialog';
import { getFileSize } from 'src/app/shared/utility/validation';
import { UserManagementService } from '../user-management.service';
import { MatTabChangeEvent } from '@angular/material/tabs';
import FileSaver from 'file-saver';
import { ConfirmationDialogComponent } from 'src/app/shared/confirmation-dialog/confirmation-dialog.component';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { TranslatePipe } from '@ngx-translate/core';

@Component({
  selector: 'app-bulk-user-creation-dialog',
  templateUrl: './bulk-user-creation-dialog.component.html',
  styleUrls: ['./bulk-user-creation-dialog.component.css'],
  encapsulation: ViewEncapsulation.None,
  providers: [TranslatePipe],
})
export class BulkUserCreationDialogComponent implements OnInit {
  public isLoadingSpinner: boolean = false;
  public isValidFileTypeOrSize: string = '';
  public file: File;
  public fileData: any;
  public onbulkUserCreation: FormGroup;
  public selctedTab: number;
  @ViewChild('myFileInput') userExcelUpload: ElementRef;
  public uploadProgress: number = 0;

  constructor(
    private dialogRef: MatDialogRef<BulkUserCreationDialogComponent>,
    @Inject(MAT_DIALOG_DATA)
    public data: {
      id: number;
      title: string;
      message: string;
      icon: string;
      configData?: {
        oldData: string;
        newData: string;
      };
      statusData: number;
      primaryBtnText: string;
      secondaryBtnText: string;
      colour: string;
    },
    public userManagementSrv: UserManagementService,
    private dialog: MatDialog,
    private http: HttpClient,
    private translatePipe: TranslatePipe
  ) {}

  ngOnInit(): void {
    this.dialogRef.updateSize('700px');
    this.onbulkUserCreation = new FormGroup({
      userDataExcel: new FormControl('', [Validators.required]),
    });
  }
  tabClick(tab: MatTabChangeEvent) {
    this.selctedTab = tab.index;
    console.log(this.selctedTab);
    this.userExcelUpload.nativeElement.value = '';
    this.onbulkUserCreation.reset();
    this.isValidFileTypeOrSize = '';
    this.uploadProgress = 0;
  }
  onFileUpload(event: Event) {
    this.isLoadingSpinner = true;
    this.file = (event.target as HTMLInputElement).files[0];
    this.onbulkUserCreation.patchValue({
      userDataExcel: this.file,
    });
    this.isLoadingSpinner = false;

    let data = getFileSize(this.file);
    if (!data) {
      this.isValidFileTypeOrSize = 'File size should not exceed than 10MB';
      this.isLoadingSpinner = false;
      return;
    }
    this.isValidFileTypeOrSize = '';
  }

  downloadSampleExcel(temType: string) {
    this.isLoadingSpinner = true;
    this.userManagementSrv
      .getBulkUserSampleTemplate(temType)
      .subscribe((response) => {
        this.isLoadingSpinner = false;
        const fileName = response.headers
          .get('Content-Disposition')
          .split('; ')[1]
          .split('=')[1];
        let blob: any = new Blob([response.body]);
        const url = window.URL.createObjectURL(blob);
        FileSaver.saveAs(blob, fileName);
      });
  }

  downloadResponseExcel(resType: string) {
    this.isLoadingSpinner = true;
    this.userManagementSrv
      .getBulkUserResponseTemplate(resType)
      .subscribe((response) => {
        this.isLoadingSpinner = false;
        const fileName = response.headers
          .get('Content-Disposition')
          .split('; ')[1]
          .split('=')[1];
        let blob: any = new Blob([response.body]);
        const url = window.URL.createObjectURL(blob);
        FileSaver.saveAs(blob, fileName);
      });
  }

  onSubmit() {
    this.isLoadingSpinner = true;
    if (this.onbulkUserCreation.invalid) {
      this.onbulkUserCreation.markAllAsTouched();
      this.userExcelUpload.nativeElement.value = '';
      return;
    }

    this.userManagementSrv
      .getBulkUserCreation(this.file, this.selctedTab)
      .subscribe(
        (event) => {
          //this.isLoadingSpinner = false;
          if (event.type === HttpEventType.Sent) {
            //console.log('Request sent');
          } else if (event.type === HttpEventType.UploadProgress) {
            let percentDone = Math.round((event.loaded / event.total) * 100);
            //console.log(percentDone)
            this.uploadProgress = percentDone;
            //console.log(`Upload progress: ${percentDone}%`);
          } else if (event.type === HttpEventType.Response) {
            //console.log('Request complete', event.body);
            this.isLoadingSpinner = false;
            this.uploadProgress = 0;
            this.dialog
              .open(ConfirmationDialogComponent, {
                data: {
                  title: this.translatePipe.transform('common.info_label'),
                  message: `${event.body.response}`,
                  icon: 'assets/images/info.svg',
                  primaryBtnText:
                    this.translatePipe.transform('common.ok_string'),
                },
                panelClass: 'common-info-dialog',
              })
              .afterClosed()
              .subscribe((result) => {
                if (result) {
                  //console.log(result)
                }
              });
          }

          this.userExcelUpload.nativeElement.value = '';
        },
        (error) => {
          this.userExcelUpload.nativeElement.value = '';
          this.isLoadingSpinner = false;
          this.uploadProgress = 0;
        }
      );
  }

  onCancel() {}
}
