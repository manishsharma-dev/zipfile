export interface SaveExcelRes {
  invalidTagIdAndBullId: string[];
  numOfRecord: number
}
