import { BullMaster } from './bull-master.model';

describe('BullMaster', () => {
  it('should create an instance', () => {
    expect(new BullMaster()).toBeTruthy();
  });
});
