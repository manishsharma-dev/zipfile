import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-edit-straw',
  templateUrl: './add-edit-straw.component.html',
  styleUrls: ['./add-edit-straw.component.css']
})
export class AddEditStrawComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
