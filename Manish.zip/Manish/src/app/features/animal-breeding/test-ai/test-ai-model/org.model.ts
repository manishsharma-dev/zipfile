export interface Organization {
  orgId: number;
  orgName: string;
  orgType: number;
  orgTypeDesc: any;
  stateCd: number;
  stateName: string;
  districtCd: number;
  districtName: string;
  orgStatus: number;
  orgStatusDesc: String;
}
