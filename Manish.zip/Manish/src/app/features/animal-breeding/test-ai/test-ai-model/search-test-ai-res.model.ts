export interface SearchTestAIRes {
  testPlanId: string;
  testPlanName: string;
  projectId?: string;
  villageCd: number;
  startDate: string;
  endDate: string;
  bullId: string;
  tagId: string;
}
