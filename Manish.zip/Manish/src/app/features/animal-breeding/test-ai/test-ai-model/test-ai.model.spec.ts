import { TestAi } from './test-ai.model';

describe('TestAi', () => {
  it('should create an instance', () => {
    expect(new TestAi()).toBeTruthy();
  });
});
