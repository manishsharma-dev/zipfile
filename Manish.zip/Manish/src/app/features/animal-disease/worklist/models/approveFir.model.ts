
export interface ApproveFIR {
    message: string;
}


export interface RejectFIR {
    message: string;
}
