import { NutritionService } from 'src/app/features/animal-nutrition/nutrition.service';
import {
  HttpInterceptor,
  HttpRequest,
  HttpHandler,
  HttpErrorResponse,
  HttpClient,
  HttpEvent,
} from '@angular/common/http';
import { ElementRef, Injectable, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { throwError } from 'rxjs';
import { catchError, filter, finalize, switchMap, take } from 'rxjs/operators';

import { AuthService } from '../features/auth/auth.service';
import {
  getDecryptedData,
  getDecryptedProjectData,
  getDecryptedRoleData,
  getSessionData,
} from '../shared/shareService/storageData';
import { MatDialog } from '@angular/material/dialog';
import { ConfirmationDialogComponent } from '../shared/confirmation-dialog/confirmation-dialog.component';
import { commonData } from '../features/animal-breeding/artificial-insemination/status-dialog/status-dialog.component';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  constructor(
    private authService: AuthService,
    private router: Router,
    private http: HttpClient,
    private nutritionService: NutritionService,
    private dialog: MatDialog
  ) {}
  private isRefreshing = false;
  private refreshTokenSubject: BehaviorSubject<any> = new BehaviorSubject<any>(
    null
  );

  intercept(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (this.authService.getToken()) {
      request = this.addToken(request, sessionStorage.getItem('token'));
    }
    if (
      request.method === 'POST' ||
      request.method === 'PUT' ||
      request.method === 'DELETE' ||
      request.method === 'PATCH'
    ) {
      const approvalRequest = requestList.find((item) =>
        request.url.includes(item)
      );
      if (approvalRequest) {
        if (
          (approvalRequest == 'updateAnimalDetails' &&
            request.body.fieldChanged != '2') ||
          approvalRequest != 'updateAnimalDetails'
        ) {
          return this.handleApprovalRequest(request, next);
        }
      } else {
        const flockApprovalRequest = flockRequestList.find((item) =>
          request.url.includes(item)
        );
        if (flockApprovalRequest) {
          if (
            (flockApprovalRequest == 'updateFlockDetails' &&
              request.body.fieldChanged != '2' &&
              request.body.fieldChanged != '3') ||
            flockApprovalRequest != 'updateFlockDetails'
          ) {
            return this.handleFlockApprovalRequest(request, next);
          }
        }
      }
    }
    return this.handleRequest(request, next);
  }

  private handleApprovalRequest(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const approvalRequestObject = this.createRequest(request);
    return this.authService.checkIfApprovalRequired(approvalRequestObject).pipe(
      switchMap((apprRes: CommonResponse) => {
        if (apprRes && apprRes.msg) {
          document
            .querySelectorAll('.overlay')
            ?.forEach(function (element: any) {
              element.style.display = 'none';
            });
          return this.showConfirmationDialog(apprRes).pipe(
            switchMap((flag) => {
              if (flag) {
                return this.handleRequest(request, next);
              } else {
                return throwError('Error');
              }
            })
          );
        } else {
          return this.handleRequest(request, next);
        }
      }),
      catchError((error) => {
        return throwError(error);
      })
    );
  }

  private handleFlockApprovalRequest(
    request: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    const approvalRequestObject = this.createFlockRequest(request);
    return this.authService
      .checkIfFlockApprovalRequired(approvalRequestObject)
      .pipe(
        switchMap((apprRes: CommonResponse) => {
          if (apprRes && apprRes.msg) {
            document
              .querySelectorAll('.overlay')
              ?.forEach(function (element: any) {
                element.style.display = 'none';
              });
            return this.showConfirmationDialog(apprRes).pipe(
              switchMap((flag) => {
                if (flag) {
                  return this.handleRequest(request, next);
                } else {
                  return throwError('Error');
                }
              })
            );
          } else {
            return this.handleRequest(request, next);
          }
        }),
        catchError((error) => {
          return throwError(error);
        })
      );
  }

  private showConfirmationDialog(res): Observable<boolean> {
    const dialogRef = this.dialog.open(ConfirmationDialogComponent, {
      data: {
        title: 'common.alert_string',
        message: res.msg.msgDesc,
        icon: 'assets/images/info.svg',
        primaryBtnText: 'common.yes',
        secondaryBtnText: 'common.no',
      },
      panelClass: ['common-info-dialog', 'new-dialog'],
    });
    return dialogRef.afterClosed().pipe(
      finalize(() => {
        document.querySelectorAll('.overlay')?.forEach((element: any) => {
          element.style.removeProperty('display');
        });
      })
    );
  }

  handleRequest(request, next): Observable<HttpEvent<any>> {
    return next.handle(request).pipe(
      catchError((error) => {
        if (error instanceof HttpErrorResponse && error.status === 401) {
          return this.handle401Error(request, next);
        } else {
          return throwError(error);
        }
      })
    );
  }

  private addToken(request: HttpRequest<any>, token: string) {
    return request.clone({
      setHeaders: {
        Authorization: `Bearer ${token}`,
        roleCd:
          getDecryptedRoleData('AESSHA256userDataRole').id?.toString() || '',
        projectId:
          getDecryptedProjectData('AESSHA256storageProjectData').id &&
          getDecryptedProjectData('AESSHA256storageProjectData').id != '0'
            ? getDecryptedProjectData('AESSHA256storageProjectData').id
            : '',
        subModuleCd: getSessionData('subModuleCd')?.subModuleCd
          ? getSessionData('subModuleCd')?.subModuleCd.toString()
          : '0',
        langCd: getSessionData('language')
          ? getSessionData('language').toString()
          : '',
      },
    });
  }

  private handle401Error(request: HttpRequest<any>, next: HttpHandler) {
    if (!this.isRefreshing) {
      this.isRefreshing = true;
      this.refreshTokenSubject.next(null);

      return this.authService.refreshToken().pipe(
        switchMap((token: any) => {
          this.isRefreshing = false;
          sessionStorage.setItem('token', token.access_token);
          sessionStorage.setItem('refresh_token', token.refresh_token);
          this.refreshTokenSubject.next(token);
          sessionStorage.setItem('token', token.access_token);
          sessionStorage.setItem('refreshToken', token.refresh_token);
          return next.handle(this.addToken(request, token.access_token));
        }),
        catchError((error) => {
          this.isRefreshing = false;
          return throwError(error);
        })
      );
    } else {
      return this.refreshTokenSubject.pipe(
        filter((token) => token != null),
        take(1),
        switchMap((token) => {
          return next.handle(this.addToken(request, token.access_token));
        })
      );
    }
  }

  createRequest(request: HttpRequest<any>) {
    let tagIdList = [];
    let animalIdList = [];
    let subModuleCd = 0;
    const approvalRequest = requestList.find((item) =>
      request.url.includes(item)
    );
    switch (approvalRequest) {
      case 'saveFirstAidDetails':
      case 'saveAIDetails':
      case 'updateAIDetails':
      case 'savePDDetails':
      case 'updatePDDetails':
      case 'saveHeatDetails':
      case 'saveEtDetails':
      case 'saveMRDetails':
      case 'updateMRDetails':
      case 'saveGMDetails':
      case 'saveTypingDetails':
        tagIdList = [request.body.tagId];
        break;
      case 'updateAnimalDetails': //sbc
        tagIdList = [request.body.tagId];
        subModuleCd = 6;
        break;
      case 'registerNewCase':
      case 'saveFollowupVisitDetails':
        tagIdList = [request.body.treatmentDetails.tagId];
        break;
      case 'saveVaccinationDetail':
      case 'saveDewormingDetail':
        tagIdList = request.body.selected_tagId_details.map(
          (tagIdList) => tagIdList.tagId
        );
        break;
      case 'saveDiseaseTesting':
        tagIdList = [request.body.diseaseTestingDetail.tagId];
        break;
      case 'savePostmortemDetail':
        tagIdList = [request.body.postmortemDetails?.tagId];
        break;
      case 'performEarTagChange': //sbc
        animalIdList = [request.body.get('animalId')];
        subModuleCd = 4;
        break;
      case 'ownerTransferInitiated': //sbc
      case 'initiateAnimalTransferAfterOwnerReg': //sbc
        animalIdList = request?.body?.animalIds;
        subModuleCd = 3;
        break;
      case 'saveCalvingDetails':
      case 'updateCalvingDetails':
      case 'savePVDetails':
        tagIdList = [request.body.get('tagId')];
        break;
      case 'saveIndividualRationBalancingDetails':
        tagIdList = JSON.parse(request.body.get('jsonObject'))?.rbAnimalDetails
          ?.tagId
          ? [JSON.parse(request.body.get('jsonObject'))?.rbAnimalDetails?.tagId]
          : [];
        break;
      case 'addAnimalAdditionalDetails':
        animalIdList = [request?.body?.animalId];
        break;
    }
    return {
      tagIdList,
      animalIdList,
      subModuleCd,
    };
  }

  createFlockRequest(request: HttpRequest<any>) {
    let flockIdsList = [];
    const approvalRequest = flockRequestList.find((item) =>
      request.url.includes(item)
    );
    switch (approvalRequest) {
      case 'updateFlockDetails':
        flockIdsList = [request.body.flockId];
        break;
      case 'saveFlockDetails':
        flockIdsList = request.body.selected_tagId_details.map(
          (tagIdList) => tagIdList.flockId
        );
        //flockIdsList = [request.body.get('flockId')];
        break;
      case 'flockEarTagChange':
        flockIdsList = [request.body.get('flockId')];
        break;
    }
    return {
      flockIdsList,
    };
  }
}

const requestList = [
  'addAnimalAdditionalDetails',
  'initiateAnimalTransferAfterOwnerReg',
  'ownerTransferInitiated',
  'performEarTagChange',
  'registerNewCase',
  'saveAIDetails',
  'saveCalvingDetails',
  'saveDewormingDetail',
  'saveDiseaseTesting',
  'saveEtDetails',
  'saveFirstAidDetails',
  'saveFollowupVisitDetails',
  'saveGMDetails',
  'saveHeatDetails',
  'saveIndividualRationBalancingDetails',
  'saveMRDetails',
  'savePDDetails',
  'savePVDetails',
  'saveTypingDetails',
  'saveVaccinationDetail',
  'updateAIDetails',
  'updateAnimalDetails',
  'updateCalvingDetails',
  'updateMRDetails',
  'updatePDDetails',
];

const flockRequestList = [
  'updateFlockDetails',
  'saveFlockDetails',
  'flockEarTagChange',
];

export interface CommonResponse {
  flg: boolean;
  data: number[];
  msg: Msg;
}

export interface Msg {
  msgCode: number;
  msgDesc: string;
}
