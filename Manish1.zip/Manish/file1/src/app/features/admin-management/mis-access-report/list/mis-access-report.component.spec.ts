import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MisAccessReportComponent } from './mis-access-report.component';

describe('MisAccessReportComponent', () => {
  let component: MisAccessReportComponent;
  let fixture: ComponentFixture<MisAccessReportComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MisAccessReportComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MisAccessReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
