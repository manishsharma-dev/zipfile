export interface MisReportAccess {
  subModuleCd: number;
  subModuleName: string;
  featureCd: number;
  isActive: string;
  effectiveFromDate: string;
  effectiveToDate: string;
  featureDesc: string;
  subModuleCode:number;
  roleCd:number
  allocationStartDate:string,
  allocationEndDate:string
  downloadFlag:boolean
  
}


