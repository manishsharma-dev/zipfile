export const AnimalBreedingConfig = {
    commonMasterKeys: {
      pv_result:"pv_result",
      sire_id_type:"sire_id_type"
    },
  
  };
  