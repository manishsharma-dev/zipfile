import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VerifyCalfModalComponent } from './verify-calf-modal.component';

describe('VerifyCalfModalComponent', () => {
  let component: VerifyCalfModalComponent;
  let fixture: ComponentFixture<VerifyCalfModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VerifyCalfModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VerifyCalfModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
