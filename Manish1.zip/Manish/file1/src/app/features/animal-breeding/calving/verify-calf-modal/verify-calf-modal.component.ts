import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { AnimalDetails } from 'src/app/features/animal-health/models/animal.model';

@Component({
  selector: 'app-verify-calf-modal',
  templateUrl: './verify-calf-modal.component.html',
  styleUrls: ['./verify-calf-modal.component.css']
})
export class VerifyCalfModalComponent implements OnInit {
  isLoadingSpinner:boolean = false
  calfDeleted :any
  constructor(
    @Inject(MAT_DIALOG_DATA)
    public data: { animalData: any },
    private dialogRef: MatDialogRef<VerifyCalfModalComponent>,
  ) {
    dialogRef.beforeClosed().subscribe(() => dialogRef.close(this.calfDeleted));
   }

  ngOnInit(): void {
    console.log(this.data)
  }
  isCalfDeleted(tag){
    this.calfDeleted = tag
  }

  onSubmit(){
    this.dialogRef.close(true);
  }


}
