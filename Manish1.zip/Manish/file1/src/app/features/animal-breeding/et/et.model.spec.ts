import { Et } from './et.model';

describe('Et', () => {
  it('should create an instance', () => {
    expect(new Et()).toBeTruthy();
  });
});
