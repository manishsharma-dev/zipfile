import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
import { EtService } from '../../et.service';
import { Location } from '@angular/common';
import { HeatDetails, HeatHistory } from '../../et.model';
import { MasterConfig } from 'src/app/shared/master.config';
import { ConfirmationDeleteDialogComponent } from 'src/app/shared/confirmation-delete-dialog/confirmation-delete-dialog.component';
import { MatDialog } from '@angular/material/dialog';
import { TranslatePipe } from '@ngx-translate/core';
import { DataServiceService } from 'src/app/shared/shareService/data-service.service';
import { animalBreedingPRConfig } from 'src/app/shared/animal-breeding-pr.config';
import { ModifyAnimalDetailsComponent } from '../../../modify-animal-details/modify-animal-details.component';

@Component({
  selector: 'app-history',
  templateUrl: './history.component.html',
  styleUrls: ['./history.component.css'],
  providers: [TranslatePipe]
})
export class HistoryComponent implements OnInit {
  masterConfig = MasterConfig
  @Input() historyDetail: any
  animalHistoryDetail: HeatHistory
  dataSource = new MatTableDataSource<HeatDetails>();
  @Output() ownerDetail = new EventEmitter();
  isLoadingSpinner: boolean = false;
  columnsToDisplay: string[] = [
    'currentLactationNo', 'heatDate', 'timeSlot', 'heatType', 'eligibleForEtFlag', 'remarks'
  ];
  tagId: number
  heatType: Array<{}>
  minAgeofAnimal: number;
  constructor(private route: ActivatedRoute,
    private router: Router,
    private etService: EtService,
    private location: Location,
    public dialog: MatDialog,
    private translatePipe: TranslatePipe,
    private dataService: DataServiceService,) { }

  ngOnInit(): void {
    this.tagId = this.route.snapshot.queryParams['tagId']
    this.getAnimalHistoryDetail(this.tagId)
    this.getHeatType()
    this.getMinAge(animalBreedingPRConfig.backdate.ETHeatBackdate)
  }
  getAnimalHistoryDetail(id: any,route?:boolean): void {
    this.isLoadingSpinner = true
    this.etService.getHeatTransactionHistory(id).subscribe((data: HeatHistory) => {
      this.animalHistoryDetail = data
      const heatDetail = this.animalHistoryDetail?.heatDetailsResponseList
      let latestHeatDetail = heatDetail?.length > 0 ? this.historyDetail ? heatDetail.splice(0, 1) : heatDetail : []
      this.dataSource = new MatTableDataSource(
        latestHeatDetail

      );
      this.ownerDetail.emit(this.animalHistoryDetail)
      this.isLoadingSpinner = false
      if (route) this.restrictionForSpecies()

    },
      error => {
        this.isLoadingSpinner = false
      }
    )
  }
  redirectionCheck(): void {
    this.router.navigate(['/not-found']);
  }

  goBack() {
    this.location.back()
  }
  restrictionForSpecies() {
    const lactNo = this.animalHistoryDetail?.animalResponse?.hasOwnProperty('currentLactationNo') &&
    this.animalHistoryDetail?.animalResponse?.currentLactationNo >= 0 ? false : true;
    if (this.animalHistoryDetail?.animalResponse?.speciesCd > 2) {
      this.confirmtionDialoug('errorMsg.breeding_service_aplicable', 'Ok');
      return
    }
     else if(this.animalHistoryDetail?.animalResponse?.pregnancyStatus == 'Y'){
      this.confirmtionDialoug('errorMsg.animal_is_pregnant', 'ok');
     }
     else if(this.animalHistoryDetail?.animalResponse?.animalStatusCd != 1) {
      this.confirmtionDialoug('errorMsg.animal_not_active', 'Ok');
    }
    else if (
      this.animalHistoryDetail?.animalResponse?.ageInMonths < this.minAgeofAnimal ||
      this.animalHistoryDetail?.animalResponse?.ageInDays ||
      !this.animalHistoryDetail?.animalResponse?.ageInMonths
    ) {
      const mesg =
        this.translatePipe.transform('errorMsg.animal_age_less') +
        this.minAgeofAnimal +
        ' ' +
        this.translatePipe.transform('animalBreeding.months_age');
      this.confirmtionDialoug(mesg, 'Ok');
    }
   else if (
      lactNo ||
      !this.animalHistoryDetail?.animalResponse?.pregnancyStatus ||
      !this.animalHistoryDetail?.animalResponse?.breed ||
      !this.animalHistoryDetail?.animalResponse?.milkingStatus
    ) {
      this.addAnimalAdditionalDetails();
    }
     else{
      console.log(this.animalHistoryDetail)
      this.router.navigate(['/dashboard/animal-breeding/et/add-heat-transaction'], {
        queryParams: { tagId: this.tagId },
      });
     }
  
  }
  private getHeatType(): void {
    this.isLoadingSpinner = true
    this.etService.getHeatType(this.tagId).subscribe((data: any) => {
      this.isLoadingSpinner = false
      this.heatType = data

    },
      error => {
        this.isLoadingSpinner = false
      }
    )
  }
  private confirmtionDialoug(message: string, button: string): void {
    this.dialog
      .open(ConfirmationDeleteDialogComponent, {
        data: {
          id: '',
          title: 'common.alert',
          message: message,
          icon: 'assets/images/alert.svg',
          primaryBtnText: 'common.ok',
        },
        panelClass: 'common-alert-dialog',
      })
      .afterClosed();
  }
  private getMinAge(age_type: string): void {
    this.dataService.getDefaultConfig(age_type).subscribe((data: any) => {
      this.minAgeofAnimal = parseInt(data?.defaultValue);
    });
  }

  addAnimalAdditionalDetails(isView?: boolean) {
    if (this.animalHistoryDetail && this.animalHistoryDetail?.animalResponse) {
      const dialogRef = this.dialog.open(ModifyAnimalDetailsComponent, {
        data: {
          animalData: this.animalHistoryDetail?.animalResponse,
        },
        width: '500px',
        height: '100vh',
        panelClass: 'custom-dialog-container',
        position: {
          right: '0px',
          top: '0px',
        },
      });
      dialogRef.afterClosed().subscribe((res) => {
        if (res) {
          this.getAnimalHistoryDetail(this.animalHistoryDetail?.animalResponse?.tagId, true)
        };
      });
    } else {
      this.confirmtionDialoug(`errorMsg.select_tag_first`, 'Ok');
    }
  }

}
