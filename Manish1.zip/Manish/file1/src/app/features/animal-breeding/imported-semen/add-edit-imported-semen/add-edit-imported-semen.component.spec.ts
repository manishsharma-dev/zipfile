import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEditImportedSemenComponent } from './add-edit-imported-semen.component';

describe('AddEditImportedSemenComponent', () => {
  let component: AddEditImportedSemenComponent;
  let fixture: ComponentFixture<AddEditImportedSemenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddEditImportedSemenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddEditImportedSemenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
