import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute } from '@angular/router';
import { TranslatePipe } from '@ngx-translate/core';
import moment from 'moment';
import { distinctUntilChanged, switchMap } from 'rxjs/operators';
import { animalBreedingPRConfig } from 'src/app/shared/animal-breeding-pr.config';
import { ConfirmationDeleteDialogComponent } from 'src/app/shared/confirmation-delete-dialog/confirmation-delete-dialog.component';
import { ConfirmationDialogComponent } from 'src/app/shared/confirmation-dialog/confirmation-dialog.component';
import { DataServiceService } from 'src/app/shared/shareService/data-service.service';
import { BullIdValidation, AlphaNumericSpecialValidation, AlphaNumericValidation, NameValidation } from 'src/app/shared/utility/validation';
import { AnimalDetail, bullDetail, breedLevels, Breed } from '../../bull-master/bull-master-model/bull-master.model';
import { BullMasterService } from '../../bull-master/bull-master.service';
import { SuccessDialogComponent } from '../../success-dialog/success-dialog.component';
import { Location } from '@angular/common';
import { AgePipe } from 'src/app/shared/utility/pipes/age.pipe';
import { AnimalManagementService } from 'src/app/features/animal-management/animal-registration/animal-management.service';


enum SEMEN_TYPE {
  S,
  C,
  B,
}

interface ArrayControl {
  bloodExoticLevelCd: string;
  breedCd: string;
}
@Component({
  selector: 'app-add-edit-imported-semen',
  templateUrl: './add-edit-imported-semen.component.html',
  styleUrls: ['./add-edit-imported-semen.component.css'],
  providers: [TranslatePipe, AgePipe],
})
export class AddEditImportedSemenComponent implements OnInit {

  currentDate = sessionStorage.getItem('serverCurrentDateTime');
  addBullFormForm: FormGroup;
  isLoadingSpinner: boolean = false;
  animalDetail: AnimalDetail;
  breedingMinDate = '';
  submitBullDetailForm: boolean = false;
  bullId: string;
  bullDetails: bullDetail;
  semenStationID: any;
  isImportedFlag: boolean = false;
  verifiedError: string;
  getCommonMasterDetail: Array<{}> = [];
  semenStationInformation: any;
  semenType: any[] = [];
  defaultDate = ''
  isSpeciesSelected: boolean = false;
  rowAdd!: FormArray;
  isAddMoreVisible: boolean = true;
  isTrashVisible: boolean = true;
  isFormValueChanged: boolean = false;
  isShowBreedError: string = '';
  isShowError: string = '';  
  breeds!: Breed[];
  constructor(
    public dialog: MatDialog,
    private _fb: FormBuilder,
    private bullMasterService: BullMasterService,
    private route: ActivatedRoute,
    private location: Location,
    private translatePipe: TranslatePipe,
    private animalMS: AnimalManagementService,
  ) { }

  ngOnInit() {
    this.semenStationID = this.route.snapshot.queryParams['semenId'];
    this.getCommonMaster();
    this.initAddAdditionalDetailForm();
    
    this.semenStationInformation = JSON.parse(
      sessionStorage.getItem('virtualBullDetails')
    );

    this.addBullFormForm
      .get('bullRegistrationDate')
      .valueChanges.pipe(distinctUntilChanged())
      .subscribe((res) => {
        const selectedDate = moment(res);

        const taggingDate = moment(this.animalDetail?.dateOfBirth);
        if (
          this.animalDetail?.dateOfBirth &&
          selectedDate.isBefore(taggingDate)
        ) {
          this.dialog
            .open(ConfirmationDialogComponent, {
              data: {
                title: this.translatePipe.transform('common.info_label'),
                message: this.translatePipe.transform(
                  'animalBreeding.please_select_date_after_animal_dob'
                ),
                primaryBtnText:
                  this.translatePipe.transform('common.ok_string'),
                icon: 'assets/images/alert.svg',
              },
              panelClass: 'common-info-dialog',
            })
            .afterClosed()
            .subscribe(() =>
              this.addBullFormForm
                .get('bullRegistrationDate')
                .setValue(this.currentDate, { emitEvent: false })
            );
        }
      });
  }

  get minDate() {
   
    return moment(this.currentDate).subtract('years', 10).format('YYYY-MM-DD');
  }

  get today() {
    return moment(this.currentDate).format('YYYY-MM-DD');
  }

  submitBullDetail(): void {
    let bullIdWithSemenStationCode: string;
    if (this.addBullFormForm.invalid 
      || this.semenType.length == 0 ||
      this.isShowError ||
      this.isShowBreedError) {
      this.submitBullDetailForm = true;
      this.addBullFormForm.controls.breedAndExoticLevelsRequest.markAllAsTouched();
      this.addBullFormForm.markAllAsTouched();
      return;
    }
    if (
      this.semenStationInformation &&
      this.semenStationInformation?.ssId?.length > 0 &&
      this.semenStationInformation?.ssId != 'null'
    ) {
      bullIdWithSemenStationCode =
        this.semenStationInformation?.ssId +
        '-' +
        this.formControls.bullId.value;
        this.addBullFormForm.get("bullId").setValue(bullIdWithSemenStationCode)
    } else {
      this.alertDialog('animalBreeding.commonLabel.semen_station_req');
      return;
    }
    const enableFormField = [
      'bullRegistrationRecordDate',
    ];
    this.isLoadingSpinner = true;
    if (this.bullId) enableFormField.push('bullId');
    this.enableForm(enableFormField, 'enable');
    const formValue = {
      ...this.addBullFormForm.getRawValue(),
    };
    formValue.bullId = bullIdWithSemenStationCode;
    formValue.animalId = this.animalDetail?.animalId;
    formValue.semenStationId = this.semenStationID
      ? this.semenStationID
      : this.bullDetails?.semenStationId;
    // formValue.bullTypeFlag =
    //   this.semenType && this.semenType?.length == 1
    //     ? parseInt(this.semenType[0]) == 1
    //       ? 'S'
    //       : 'C'
    //     : this.semenType?.length > 1
    //       ? 'B'
    //       : null;
    const sumbit = this.bullId
      ? 'animalBreeding.commonLabel.bull_update'
      : 'animalBreeding.commonLabel.bull_submit';
    formValue.bullRegistrationDate = moment(
      formValue.bullRegistrationDate
    ).format('YYYY-MM-DD');
    this.bullMasterService[
      this.bullId ? 'updateBullMastersDetails' : 'saveVirtualMastersDetails'
    ](formValue)
      .pipe(
        switchMap((res: any) => {
          return this.dialog
            .open(SuccessDialogComponent, {
              data: {
                title: sumbit,
              },
              width: '500px',
              panelClass: 'makeItMiddle',
            })
            .afterClosed();
        })
      )
      .subscribe(
        () => {
          this.isLoadingSpinner = false;
          this.submitBullDetailForm = false;
          this.goBack();
        },
        (error) => {
          this.enableForm(enableFormField, 'disable');
          this.isLoadingSpinner = false;
        }
      );
  }


 
  get formControls() {
    return this.addBullFormForm.controls;
  }
  private initAddAdditionalDetailForm(): void {
    this.addBullFormForm = this._fb.group({
      bullRegistrationRecordDate: [
        { value: this.today, disabled: true },
        [Validators.required],
      ],
      bullRegistrationDate: [
        this.today,
        { updateOn: 'blur', validators: [Validators.required] },
      ],
      importedSemenFlag: ['Y', [Validators.required]],
     
      bullId: [
        '',
        [Validators.required, Validators.maxLength(30), BullIdValidation],
      ],
      nominatedBullFlag: ['Y', [Validators.required]],
      etBullFlag: [''],
      bullSource: [{value:4,disabled: true}, [Validators.required]],
      breed: [''],
      bullStatus: [1, [Validators.required]],
      speciesCd:[null,[Validators.required]],
      importedNaabCd: [
        '',
        [Validators.required, AlphaNumericSpecialValidation],
      ],
      importedRegName: [
        '',
        [Validators.required, NameValidation],
      ],
      importedRegNo: ['', [Validators.required, AlphaNumericSpecialValidation]],
      importingAgency: [
        '',
        [Validators.required, NameValidation],
      ],
      importedFrom: ['', [Validators.required, AlphaNumericSpecialValidation]],
      importedScheme: ['', [Validators.required,AlphaNumericSpecialValidation]],
      importedBy: ['',[Validators.required, AlphaNumericSpecialValidation]],
      bullTypeFlag: ['', [Validators.required, AlphaNumericValidation]],
      breedAndExoticLevelsRequest: this._fb.array([]),
    });
    
    this.formControls.speciesCd.valueChanges.subscribe((value) => {
     if(value) {
      this.isSpeciesSelected = true
      this.onSelectingSpecies(value)
    }
     else this.isSpeciesSelected = false
    });

    this.addRow();
      this.checkBloodLevel();

  }

  goBack(): void {
    this.location.back();
  }
  onCheckChange(event) {
    const isTypeAvailable =
      this.semenType && this.semenType?.length > 0
        ? this.semenType.filter((type) => type == event.cd)
        : [];
    if (!event.checked && isTypeAvailable.length == 0) {
      this.getCommonMasterDetail['semen_type'] = this.getCommonMasterDetail[
        'semen_type'
      ].map((p) => (p.cd == event.cd ? { ...p, checked: true } : p));
      this.semenType.push(event.cd);
    } else {
      this.semenType = this.semenType.filter((type) => type !== event.cd);

      this.getCommonMasterDetail['semen_type'] = this.getCommonMasterDetail[
        'semen_type'
      ].map((p) => (p.cd == event.cd ? { ...p, checked: false } : p));
    }
   const semenType =  this.semenType && this.semenType?.length == 1
        ? parseInt(this.semenType[0]) == 1
          ? 'S'
          : 'C'
        : this.semenType?.length > 1
          ? 'B'
          : null;
          this.addBullFormForm.get("bullTypeFlag").setValue(semenType)
  }

  
  private enableForm(formName: Array<any>, type: string): void {
    formName.forEach((element) => {
      this.addBullFormForm?.get(element)[type]();
    });
  }


  private getCommonMaster(): void {
    this.isLoadingSpinner = true;
    const key = ['bull_source', 'semen_type','species','blood_exotic_level'];
    key.forEach((val) => {
      this.bullMasterService.getCommonMaster(val).subscribe(
        (data) => {
          this.isLoadingSpinner = false;
          this.getCommonMasterDetail[val] = data;
          this.getCommonMasterDetail[val] = this.getCommonMasterDetail[val].map(
            (v) => ({
              ...v,
              checked: false,
            })
          );
        },
        (error) => {
          this.isLoadingSpinner = false;
        }
      );
    });
  }


  private alertDialog(message: string): void {
    this.dialog
      .open(ConfirmationDeleteDialogComponent, {
        data: {
          id: '',
          title: 'common.alert',
          message: message,
          icon: 'assets/images/alert.svg',
          primaryBtnText: 'Ok',
          // secondaryBtnText: 'No',
        },
        panelClass: 'common-alert-dialog',
      })
      .afterClosed();
  }
  convertInputToUpperCase(event: Event) {
    const element = event.target as HTMLInputElement;
    const position = element?.selectionStart;
    element.value = element?.value?.toString()?.toLocaleUpperCase();
    element?.setSelectionRange(position, position);
  }

  get formRowTitles() {
    return (this.addBullFormForm.get('breedAndExoticLevelsRequest') as FormArray)[
      'controls'
    ];
  }
  addRow(breedCd?: string, bloodExoticLevelCd?: string) {
    this.rowAdd = this.addBullFormForm.get(
      'breedAndExoticLevelsRequest'
    ) as FormArray;
    if (this.rowAdd.length < 4) {
      this.rowAdd.push(this.createRow(breedCd, bloodExoticLevelCd));
    }
  }

  createRow(breedCd?: string, bloodExoticLevelCd?: string) {
    if (breedCd != undefined && bloodExoticLevelCd != undefined) {
      this.isAddMoreVisible = false;
      this.isTrashVisible = false;
    }
    return this._fb.group({
      bloodExoticLevelCd: [
        {
          value: bloodExoticLevelCd || '',
          disabled: bloodExoticLevelCd != undefined,
        },
        Validators.required,
      ],
      breedCd: [
        { value: breedCd || '', disabled: breedCd != undefined },
        Validators.required,
      ],
    });
  }
  checkBloodLevel() {
    this.addBullFormForm
      .get('breedAndExoticLevelsRequest')
      ?.valueChanges.subscribe((data) => {
        this.isFormValueChanged = true;
        let selectedPercentage = 0;
        for (let i of data) {
          selectedPercentage += +i?.bloodExoticLevelCd;
        }
        if (selectedPercentage > 100) {
          this.isShowError =
            'errorMsg.blood_exotic_greater';
          this.isAddMoreVisible = false;
        } else if (selectedPercentage < 100) {
          this.isShowError =
            'errorMsg.blood_exotic_less';
          this.isAddMoreVisible = true;
        } else {
          this.isAddMoreVisible = false;
          this.isShowError = '';
        }
      });
  }
  onBreedSelect() {
    this.checkDuplicateBreed();
  }

  checkDuplicateBreed() {
    const dup = this.addBullFormForm.value.breedAndExoticLevelsRequest
      .map((val: ArrayControl) => val.breedCd)
      .filter(
        (val: ArrayControl, i: number, breed: ArrayControl[]) =>
          breed.indexOf(val) != i
      );
    const dupBreed = this.addBullFormForm.value.breedAndExoticLevelsRequest.filter(
      (obj: ArrayControl) => obj.breedCd && dup.includes(obj.breedCd)
    );
    if (dupBreed.length > 1) {
      this.isShowBreedError =
        'errorMsg.breed_already_exist';
    } else {
      this.isShowBreedError = '';
    }
  }

  get exoticLevelArray() {
    return this.addBullFormForm.get('breedAndExoticLevelsRequest') as FormArray;
  }

  onSelectingSpecies(speciesCode:number) {
    var selectedSpecies = String(speciesCode);
    this.animalMS.getBreeds(selectedSpecies).subscribe((breeds) => {
      this.breeds = breeds;
    });
  }
  removeRow(i: number) {
    let deletedRow = this.addBullFormForm.get(
      'breedAndExoticLevelsRequest'
    ) as FormArray;
    deletedRow.removeAt(i);
    this.checkDuplicateBreed();
  }
 
}
