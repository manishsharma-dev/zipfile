import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ImportedSemenListComponent } from './imported-semen-list.component';

describe('ImportedSemenListComponent', () => {
  let component: ImportedSemenListComponent;
  let fixture: ComponentFixture<ImportedSemenListComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ImportedSemenListComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ImportedSemenListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
