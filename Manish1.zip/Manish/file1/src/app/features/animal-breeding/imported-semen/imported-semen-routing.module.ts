import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ImportedSemenListComponent } from './imported-semen-list/imported-semen-list.component';
import { AddEditImportedSemenComponent } from './add-edit-imported-semen/add-edit-imported-semen.component';
import { VirtualBullDetailsComponent } from './virtual-bull-details/virtual-bull-details.component';

const routes: Routes = [
  {
    path:"virtual-bull-list",
   component:ImportedSemenListComponent
  },
  {
    path:"add-virtual-bull",
   component:AddEditImportedSemenComponent
  },
  {
    path:"view-virtual-bull-detail",
    component:VirtualBullDetailsComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ImportedSemenRoutingModule { }
