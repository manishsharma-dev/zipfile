import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ImportedSemenRoutingModule } from './imported-semen-routing.module';
import { ImportedSemenListComponent } from './imported-semen-list/imported-semen-list.component';
import { AddEditImportedSemenComponent } from './add-edit-imported-semen/add-edit-imported-semen.component';
import { ViewImportedSemenComponent } from './view-imported-semen/view-imported-semen.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { VirtualBullDetailsComponent } from './virtual-bull-details/virtual-bull-details.component';


@NgModule({
  declarations: [
    ImportedSemenListComponent,
    AddEditImportedSemenComponent,
    ViewImportedSemenComponent,
    VirtualBullDetailsComponent
  ],
  imports: [
    CommonModule,
    ImportedSemenRoutingModule,
    SharedModule
  ]
})
export class ImportedSemenModule { }
