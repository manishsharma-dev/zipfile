import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewImportedSemenComponent } from './view-imported-semen.component';

describe('ViewImportedSemenComponent', () => {
  let component: ViewImportedSemenComponent;
  let fixture: ComponentFixture<ViewImportedSemenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewImportedSemenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewImportedSemenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
