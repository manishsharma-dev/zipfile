import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-imported-semen',
  templateUrl: './view-imported-semen.component.html',
  styleUrls: ['./view-imported-semen.component.css']
})
export class ViewImportedSemenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
