import { ComponentFixture, TestBed } from '@angular/core/testing';

import { VirtualBullDetailsComponent } from './virtual-bull-details.component';

describe('VirtualBullDetailsComponent', () => {
  let component: VirtualBullDetailsComponent;
  let fixture: ComponentFixture<VirtualBullDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ VirtualBullDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(VirtualBullDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
